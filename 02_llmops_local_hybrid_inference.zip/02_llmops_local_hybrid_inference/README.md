# LLMOps Platform for Local and Hybrid Inference

Production-style LLM/SLM serving platform with FastAPI, local/remote routing, observability, latency logging, and Docker deployment.

## Features

- FastAPI inference APIs
- Local model serving through Ollama
- Remote fallback through Hugging Face Inference API
- Model routing
- Latency benchmarking
- JSONL observability logs
- Metrics endpoint
- Dockerized serving

## Run locally

Start Ollama:

```bash
ollama run phi3
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Run API:

```bash
uvicorn api.main:app --reload --host 0.0.0.0 --port 8000
```

Open docs:

```text
http://localhost:8000/docs
```

## Test request

```bash
curl -X POST "http://localhost:8000/infer" \
  -H "Content-Type: application/json" \
  -d '{
    "task": "summarization",
    "text": "This report discusses sanitation, clean water, and child health programs.",
    "model_preference": "auto"
  }'
```

## Endpoints

| Endpoint | Purpose |
|---|---|
| `/health` | Health check |
| `/infer` | Model inference |
| `/metrics` | Latency and reliability metrics |
| `/models` | Model registry and routing policy |

## Environment variables

```bash
export LOCAL_MODEL=phi3
export OLLAMA_URL=http://localhost:11434/api/generate
export HF_TOKEN=your_token
export HF_API_URL=https://api-inference.huggingface.co/models/microsoft/Phi-3-mini-4k-instruct
```
